import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib import rc
'''
Figure : 그래프를 그리는 캔바스다(하나의 윈도우)
         Figure는 하나 이상의 Axes(subplot)로 구성된다
Axes(plot):하나의 그래프를 의미
           하나의 Axes는 두 개의 axis를 갖는다    


'''


font= fm.FontProperties(fname=r'C:\Windows\Fonts\gulim.ttc',size=18).get_name()
rc('font',family=font)

print('[여라 라인플롯 그리기]')
x=range(0,5)
plt.title('하나의 Axes에 여러개의 라인 플롯 그리기')
y1 = [i*2 for i in x] #y=2x
y2 = [i*3 for i in x] #y=3x
#방법1:하나의 plot함수 사용:x데이타,y데이타,스타일 이거를 계속 반복,이때는 x데이타 와 스타일 생략 불가
#plt.plot(x,y1,'r:o',x,y2,'b*-.',x,x,'g+-.')
#방법2:여러개의 plot함수 사용:각 라인별 style을 추가 조정 가능
plt.plot(x,y1,color='r',linestyle=':',linewidth=5,label='첫번째라인')#label에 지정한 값은 범례에 표시된다
plt.plot(x,y2,color='g',linestyle='-.',label='두번째라인')
plt.plot(x,x,color='b',linestyle='--',label='세번째라인')
#https://matplotlib.org/api/legend_api.html?highlight=legend#module-matplotlib.legend
plt.legend(loc='upper left')#범례표시 하기위한 함수 호출.loc인자로 범레의 위치 조절: 문자열 혹은 숫자(디폴트:best)
#X,Y축에 레이블 표시
plt.xlabel('X축 데이타')
plt.ylabel('Y축 데이타')
plt.show()


