#!/usr/bin/env python
# coding: utf-8

# In[1]:


#라이브러리 불러오기
import numpy as np
import pandas as pd


# In[2]:


import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib import rc
import seaborn as sns


# In[3]:


font= fm.FontProperties(fname=r'C:\Windows\Fonts\gulim.ttc',size=18).get_name()
rc('font',family=font)


# In[4]:


df=pd.read_csv('../pandaslib/data/demo.csv')


# In[5]:


df.shape


# In[6]:


df.head()


# In[7]:


df.info()


# In[8]:


df.isnull().sum()


# In[9]:


df.columns


# In[10]:


#3749370갯수의 데이타에서 요청 IP는 몇개인지
df['c_ip'].unique()


# In[11]:


df['c_ip'].nunique()#2,793개의 아이피에서 3,749,370번의 요청이 들어옴


# In[12]:


#응답시간의 통계치 보기
df['time_taken'].describe()


# In[13]:


#응답 코드 분석
df['sc_status'].unique()


# In[14]:


#응답코드별 빈도수
df['sc_status'].value_counts()


# In[15]:


df_status=df.query('sc_status==200 | sc_status==404 | sc_status==401 | sc_status==500')


# In[16]:


df_status.groupby('sc_status').size()
df_status


# In[17]:


sns.countplot(x='sc_status',data=df_status)


# In[18]:


#HTTP METHOD 분석
df['cs_method'].unique()


# In[19]:


method=df['cs_method'].value_counts()
method


# In[20]:


#시리즈를 데이타프레임으로 변경
method=method.reset_index()
method


# In[21]:


#컬럼명 변경
method.columns=['http_method','request']


# In[22]:


method=method.query('http_method=="GET" | http_method=="POST" | http_method=="DELETE" | http_method=="PUT"')


# In[23]:


method


# In[27]:


sns.barplot(x='http_method',y='request',data=method)


# In[28]:


#countplot는 http_method컬럼의 값별로 빈도수로  그린다 즉 GET=1,POST=1,DELETE=1,PUT=1
sns.countplot(x='http_method',data=method)


# In[ ]:




