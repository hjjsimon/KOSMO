#!/usr/bin/env python
# coding: utf-8

# ## pivot_table 사용예를 위한 예제

# In[1]:


#라이브러리 불러오기
import numpy as np
import pandas as pd


# In[2]:


df=pd.read_csv('./data/도로교통공단_사망 교통사고 정보_20201231.csv')


# In[3]:


df.columns


# ### groupby

# In[4]:


#요일 컬럼으로 그룹핑해서 각 컬럼(수치데이타)별 집계
df.groupby('요일').max()


# In[10]:


df.groupby('요일').count()#요일 컬럼으로 그룹핑해서 각 컬럼별 빈도수(범주형 포함).데이타 프레임으로 반환
#df.groupby('요일').size()#요일 컬럼으로 그룹핑해서 그룹핑된 요일별로 빈도수.시리즈로 반환


# In[6]:


#SELECT COUNT('사망자수'),MAX('사망자수'),MIN('사망자수') FROM DF GROUP BY 사고유형_대분류,사고유형_중분류
df.groupby(['사고유형_대분류','사고유형_중분류'])['사망자수'].agg(['count','max','min'])


# ### pivot_table

# In[7]:


#groupby와 거의 같은 기능이나 직관적이다
df.groupby('요일').count()


# In[17]:


#df.pivot_table(columns='요일',aggfunc='count')#요일 컬럼의 유니크한 값을 컬럼인덱스로 사용
##요일 컬럼의 유니크한 값을 행인덱스로 사용
df.pivot_table(index='요일',aggfunc='count')#df.groupby('요일').count()와 같다
df.pivot_table(index='요일',aggfunc='size')#df.groupby('요일').size()와 같다


# In[14]:


#df.groupby(['사고유형_대분류','사고유형_중분류'])['사망자수'].agg(['count','max','min'])
df.pivot_table(index=['사고유형_대분류','사고유형_중분류'],values='사망자수',aggfunc=['count','max','min'])


# In[ ]:




