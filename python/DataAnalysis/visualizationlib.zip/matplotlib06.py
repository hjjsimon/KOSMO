import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np
from matplotlib import rc
font= fm.FontProperties(fname=r'C:\Windows\Fonts\gulim.ttc',size=18).get_name()
rc('font',family=font)

print('[파이차트 그리기]')
plt.title('각 커리큘럼의 비율')
curriculum =['자바','파이썬','안드로이드','스프링','데이타베이스']
ration=[35,15,20,15,15]
colors=['red','green','blue','yellow','#f7a890']
plt.pie(x=ration,labels=curriculum,colors=colors,shadow=True,startangle=90,autopct='%.1f%%' )
plt.show()