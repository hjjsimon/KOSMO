import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np
from matplotlib import rc
font= fm.FontProperties(fname=r'C:\Windows\Fonts\gulim.ttc',size=18).get_name()
rc('font',family=font)

print('[막대 그래프 그리기]')


#막대에 데이타 수치(고도:altitude)를 표시하려면 아래 두줄이 필요함
fig = plt.figure(figsize=(12,8))
axes = fig.add_subplot(1,1,1)#1행 1열짜리 AXES.인덱스는 고로 하나니까 1

plt.title('산의 높이 비교')
mountains=['설악산','덕유산','속리산','태백산','대둔산','비슬산','소백산','한라산','성인봉']#막대 레이블
y=[2023,2003,1895,1930,1745,1456,2030,2090,1090]#막대 데이타(Y좌표)
#아래 두 줄은 plt.bar(mountains,y,color='g')와 같다
x=range(len(mountains))
plt.xticks(x,mountains)#X축에 산이름으로 티커표시
plt.ylabel('고도')
#수직 막대 그리기
rects=plt.bar(x,y,color='g')
print(dir(rects))#<BarContainer object of 9 artists>

#막대에 데이타 수치 표시하기
for index,rect in enumerate(rects):
    pass
    #print(rect)#Rectangle(xy=(-0.4, 0), width=0.8, height=2023, angle=0) xy는 사각형의 left bottom의 x,y좌표
    #print(rect.get_x()+rect.get_width()/2)#index와 같다 즉 막대의 정 중앙 X좌표
    #print(rect.get_height()*0.9)#막대높이의 90%지점을 Y좌표
    #axes.text(,1,'안녕')#axes.text(x좌표,y좌표,'텍스트')
    axes.text(rect.get_x()+rect.get_width()/2,rect.get_height()*0.9,str(rect.get_height())+'미터',horizontalalignment='center',fontdict={'color':'white','size':12})

plt.show()



