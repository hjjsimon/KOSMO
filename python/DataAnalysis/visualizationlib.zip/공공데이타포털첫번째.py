#!/usr/bin/env python
# coding: utf-8

# ## 공공데이타 포털에서 데이타셋 다운 로드

# #### https://www.data.go.kr/ 에서 데이타찾기->데이타 목록->교통사고로 검색->파일데이타->도로교통공단_사망 교통사고 정보 클릭->다운로드

# In[1]:


#라이브러리 불러오기
import numpy as np
import pandas as pd


# In[2]:


import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib import rc
import seaborn as sns


# In[3]:


font= fm.FontProperties(fname=r'C:\Windows\Fonts\gulim.ttc',size=18).get_name()
rc('font',family=font)


# In[4]:


#파일 불러오기(다운로드 파일 불러오면 인코딩 에러 발생)
#해결책 1 - encoding='cp949' 추가
#df=pd.read_csv('./data/도로교통공단_사망 교통사고 정보_20201231.csv',encoding='cp949')
#해결책 2 - 파일을 메모장으로 열어서 "다름 이름으로 저장" 인코딩을 utf-8로 선택후 저장
df=pd.read_csv('./data/도로교통공단_사망 교통사고 정보_20201231.csv')


# In[5]:


df.shape


# In[6]:


df.head()


# In[7]:


df.info()


# In[8]:


df.columns


# #### 결측치 다루기 

# ##### 결측치가 1000(임의로 정함)개 이상인 컬럼들은 제거하자

# In[9]:


df.isna().sum()#컬럼별 결측치 . 결측치가 없다


# In[10]:


#결측치 없어서 일부러 결측치를 가진 컬럼을 추가하자
df['추가컬럼2']=np.nan # 컬럼을 끝에 추가


# In[11]:


df.insert(5,'추가컬럼1',np.nan)#인덱스가 5인 열에 컬럼명은 '추가컬럼1' 으로 중간에 삽입


# In[12]:


df.columns


# ###### 1. 컬럼별 결측치 수 파악

# In[13]:


nan = df.isnull().sum()
nan


# ##### 2.결측치 시리즈 데이타를 데이타프레임으로 변환

# In[14]:


#시리즈의 색인(컬럼명)을 데이타프레임의 컬럼으로 변경하기 위한 작업:reset_index()
df_nan=nan.reset_index()#시리즈를 데이타프레인으로 변경(시리즈의 색인명과 데이타가 데이타프레임의 데이타가 된다)
                        #이때 데이타 프레임의 행 색인은 정수 색인이고 컬럼색인은 index 와  0(색인명이 없을때) 혹은 색인명이 된다
df_nan


# ##### 3. 컬럼인덱스 변경

# In[15]:


#컬럼인덱스 변경하기 :['index', 0] ->['컬럼명','결측치수']
df_nan.columns =['컬럼명','결측치수']
df_nan


# In[16]:


#결측치수를 기준으로 내림차순 정렬
df_nan.sort_values(by='결측치수',ascending=False)


# ##### 4.결측치가 1000개 이상  있는 행들의 모든 컬럼들 보기

# In[17]:


#결측치가 1000개 이상  있는 행들의 모든 컬럼들 보기
df_nan_columns=df_nan.loc[df_nan['결측치수'] >=1000,:]#df_nan[df_nan['결측치수'] >=1000]와 같다
df_nan_columns


# ##### 5. 1000개이상인 컬럼명들을 리스트로 변환

# In[18]:


drop_columns=df_nan_columns['컬럼명'].tolist()
drop_columns


# ##### 6. 1000개이상인 컬럼명들 제거

# In[19]:


#결측치가 1000개 이상인 컬럼들은 제거하자
#열을 기준으로 삭제해야 하기 때문에 axis = 1을 지정. 행을 삭제하려면 0(디폴트)
df.drop(drop_columns,axis=1,inplace=True)


# In[20]:


df.columns


# In[21]:


#전체 컬럼에 대한 수치 통계정보 보기(디폴트가 수치형만)
df.describe()#include='number' 디폴트


# In[22]:


#특정 컬럼에 대한 수치 통계정보 보기(디폴트가 수치형만)
df[['사망자수','중상자수']].describe()


# In[23]:


#수치 데이타뿐만 아니라 모든 타입의 컬럼들에 대한 통계수치 보기
df.describe(include='all')#unique ,top(가장 높은 빈도로 출현하는 데이터),freq(가장 높은 빈도로 출현한 데이터의 빈도수) 추가됨


# In[24]:


#요일별 교통사고 발생 건수
df.groupby(by='요일').size().sort_values(ascending=False)#요일별 카운트 수로 freq가 482 확인
df['요일'].value_counts().sort_values(ascending=False)


# In[25]:


#발생지시도가 어디인가?
df['발생지시도'].unique()
#df['발생지시도'].nunique()#유니크한 갯수(n는 number)


# In[26]:


#발생지시도별 교통사고 발생 건수
#df.groupby('발생지시도').size().sort_values() 혹은
sido=df['발생지시도'].value_counts().sort_values(ascending=False)
sido


# In[96]:


#발생지시도별 요일별 사망자수
#death_count=df.groupby(['발생지시도','요일'])['사망자수'].agg(['count'])
death_count=df.groupby(['발생지시도','요일'])['사망자수'].count()
death_count.index#MultiIndex
#MultiIndex를 Index로 변환
death_count = death_count.reset_index()
death_count


# In[86]:


#발생지시도별 요일별 사망자수 시각화
plt.figure(figsize=(12,8))
plt.xticks(rotation=45)
sns.barplot(data=death_count,x='발생지시도',y='count',hue='요일')


# In[28]:


#사고유형은 어떤거?
df['사고유형'].unique()


# In[29]:


#사고유형별 교통사고 건수
df.groupby('사고유형').size().sort_values(ascending=False)
df['사고유형'].value_counts().sort_values(ascending=False)


# In[30]:


#발생지시도가 서울인 교통사고 데이타만 추출
seoul=df[df['발생지시도']=='서울']
seoul.head()


# In[31]:


#서울의 요일별 교통사고 발생 빈도수(전국은 수요일,서울은 금요일에 가장 많이 발생)
weekday=seoul['요일'].value_counts()
#weekday.name : 요일
weekday


# In[32]:


weekday=weekday.reset_index()#시리즈를 데이타프레임으로 변경
weekday


# In[33]:


#weekday의 컬럼색인 변경
weekday.columns=['요일','발생건수']
weekday


# #### 시각화하기

# In[34]:


sns.barplot(x='요일',y='발생건수',data=weekday)#서울지역만(weekday 데이타프레임으로)


# In[35]:


sns.countplot(x='요일',data=df[df['발생지시도']=='서울'])#서울지역만(df 데이타 프레임으로)


# In[36]:


#서울에서는 어느 시군구가 교통사고가 많이 발행하는가?
seoul['발생지시군구'].value_counts().sort_values(ascending=False)


# In[37]:


plt.figure(figsize=(12,8))
plt.xticks(rotation=45)
sns.countplot(x='발생지시군구',data=seoul)


# In[38]:


#발생지시도가 서울이고 가해자_당사자종별가 승용차인 행만 추출
df_seoul_sedan=seoul[seoul['가해자_당사자종별']=='승용차']
df_seoul_sedan.shape


# In[39]:


seoul_sedan_sigungu=df_seoul_sedan['발생지시군구'].value_counts()
seoul_sedan_sigungu


# In[40]:


plt.figure(figsize=(12,8))
plt.xticks(rotation=45)
sns.countplot(x='발생지시군구',data=df_seoul_sedan)


# In[98]:


#서울의 발생지시군구 요일별 사망자수
#death_count=df.groupby(['발생지시도','요일'])['사망자수'].agg(['count'])
death_count=seoul.groupby(['발생지시군구','요일'])['사망자수'].count()
#MultiIndex를 Index로 변환
death_count = death_count.reset_index()
death_count


# In[92]:


#서울의 발생지시군구별 요일별 사망자수 시각화
plt.figure(figsize=(12,8))
plt.xticks(rotation=45)
sns.barplot(data=death_count,x='발생지시군구',y='사망자수',hue='요일')


# In[41]:


#가해자_당사자종별이 승용차인  서울의 시군구명만 리스트로 변환
seoul_sedan_sigungu.index.tolist()


# In[42]:


#위의 시군구명을 넘파이 배열로 변환
#np.array(seoul_sedan_sigungu.index)#dtype=object
np.array(seoul_sedan_sigungu.index.tolist())#dtype='<U4'


# In[43]:


#도로형태에서  '기타'가 포함된 행은 제외
df_seoul_sedan['도로형태'].unique()


# In[44]:


df_seoul_sedan=df_seoul_sedan[df_seoul_sedan['도로형태'].str.find('기타') == -1]
df_seoul_sedan[df_seoul_sedan['도로형태'].str.find('기타') == -1]['도로형태'].unique() #기타가 포함안된 행들


# #### 서울지역에서 발생한 교통사고를 지도로 보기

# In[45]:


sns.scatterplot(x='위도',y='경도',data=seoul)


# ## Folium을 사용하기 위해선 직접 Anaconda prompt에 conda install -c conda-forge folium을 입력하여 설치
# #### https://python-visualization.github.io/folium/

# In[46]:


import folium


# In[47]:


#교통사고가 발생한 위치(서울지역)의 위도와 경도  평균
lat = seoul['위도'].mean()
lng = seoul['경도'].mean()
map = folium.Map(location=[lat,lng],zoom_start=12)


# In[48]:


map


# In[49]:


#서울의 각 지역의 사망자수 와 부상자수(동대문구로 한정)
seoul.query('발생지시군구=="동대문구"').loc[:,['위도','경도','사망자수','부상자수']]#위도아 경도가 반올림된 값임
#37.57986275 ,127.0383918
#seoul.query('위도==37.57986275 & 경도==127.0383918')[['사망자수','부상자수','발생지시군구']]


# In[50]:


#위 서울지도에 교통사고가 발생한 위치에 마커 표시
for row_index in seoul.index:
    death_count = seoul.loc[row_index,'사망자수']
    accident_count = seoul.loc[row_index,'부상자수']
    lat = seoul.loc[row_index,'위도']
    lng = seoul.loc[row_index,'경도']
    popuptext = '<h4>사망자수:{}</h4><h5>부상자수:{}</h5><h6>위도:{}</h6><h6>경도:{}</h6>'.format(death_count,accident_count,lat,lng)
    
    location=[lat,lng]
    iframe = folium.IFrame(popuptext,width=150,height=100)
    popup=folium.Popup(iframe)
    folium.Marker(location=location,popup=popup).add_to(map)


# In[51]:


map


# In[52]:


#위 지도를 HMTL로 저장
map.save('index.html')

