import matplotlib.pyplot as plt
print('[Y좌표만으로 그래프 그리기]')#디폴트는 라인 플롯
#plt.plot([1,2,3])#y=[1,2,3].데이타는 리스트 혹은 튜플 y=x+1 그래프 즉 x=[0,1,2]
#'스타일' 설정
#https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.plot.html?highlight=plot#matplotlib.axes.Axes.plot
plt.plot([1,2,3],'r^-.')# 스타일은 '색상,마커,라인스타일'
plt.show()
print('[X,Y좌표로 그래프 그리기]')
x=range(1,4)
y=[i *2 for i in x]#f(x)= 2x
#plt.plot(x,y,marker='o')
#plt.plot(x,y,marker='o',color='g',linestyle=':')#plt.plot(x,y,'og:')와 같다
plt.plot(x,y,'og:')
#x축 y축 값 설정:plt.axis() 혹은 xticks()와 yticks()
#plt.axis([x[0],x[len(x)-1],y[0],y[len(y)-1]])#[x축 시작값,x축 끝값,y축 시작값,y축 끝값]
plt.xticks(x)
plt.yticks(y)
plt.show()
